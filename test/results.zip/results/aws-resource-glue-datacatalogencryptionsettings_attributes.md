# AWS::Glue::DataCatalogEncryptionSettings

### Ref
