# AWS::EC2::GatewayRouteTableAssociation

### Ref

When you pass the logical ID of this resource to the intrinsic `Ref` function, `Ref` returns the ID of the gateway\.

### Fn::GetAtt

The `Fn::GetAtt` intrinsic function returns a value for a specified attribute of this type\. The following are the available attributes and sample return values\.


#### 

`AssociationId`  
The ID of the route table association\.
