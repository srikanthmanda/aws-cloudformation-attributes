# AWS::SageMaker::Workteam

### Ref

### Fn::GetAtt

#### 

`WorkteamName`  
Not currently supported by AWS CloudFormation\.
