# AWS::SageMaker::CodeRepository

### Ref

### Fn::GetAtt

#### 

`CodeRepositoryName`  
Not currently supported by AWS CloudFormation\.
