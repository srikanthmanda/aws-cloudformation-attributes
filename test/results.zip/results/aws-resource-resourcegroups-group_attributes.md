# AWS::ResourceGroups::Group

### Ref

The name of a resource group\.

### Fn::GetAtt

#### 

`Arn`  
The ARN of a resource group\.

