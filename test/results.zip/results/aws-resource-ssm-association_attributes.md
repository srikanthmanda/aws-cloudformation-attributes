# AWS::SSM::Association

### Fn::GetAtt

#### 

`AssociationId`  
Not currently supported by AWS CloudFormation\.

