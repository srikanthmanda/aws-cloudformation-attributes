# AWS::Glue::SecurityConfiguration

### Ref
